import React from "react";

export default function GenButn() {
  return (
    <>
      <button type="submit" value={"Generate"} className="genbtn">
        {"Generate ➡️"}
      </button>
    </>
  );
}
